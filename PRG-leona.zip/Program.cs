﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace RPG
{
  class Program
  {
    static void Main(string[] args)
    {
      Game game = new Game();

      game.Start();
      
      // System.Console.WriteLine(Console.ReadKey().Key.ToString());
    }
    
  }
}
